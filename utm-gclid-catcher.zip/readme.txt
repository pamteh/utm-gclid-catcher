UTM & GCLID catcher
Contributors: pamteh
Tags: gclid, utm
Requires at least: 4.7
Tested up to: 6.6.1
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
This plugin captures and saves UTM tags and the Google Click Identifier (GCLID) in cookies, enabling them to be sent through WPForms.